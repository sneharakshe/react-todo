# Todo List App in ReactJS.

todo list app develped using reactjs.

## Technologies used:

* HTML.
* CSS.
* React JS.
* React Responsive Modal.

## Silent features:

* User can add unlimited todos.
* User can delete, edit and shift up and shift down the todo's.
* User can remove all the todo's at once.

## Project Preview:

[ToDo App ReactJS](https://alitahir4024.github.io/todolist-app-react/)
